define("Form1", function() {
    return function(controller) {
        function addWidgetsForm1() {
            this.setDefaultUnit(voltmx.flex.DP);
            var flxBody = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "83.79%",
                "horizontalScrollIndicator": true,
                "id": "flxBody",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": voltmx.flex.SCROLL_VERTICAL,
                "skin": "CopyslFbox0hf91ef37f75a4c",
                "top": "116dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxBody.setDefaultUnit(voltmx.flex.DP);
            var tbxInputString = new voltmx.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerX": "50%",
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "tbxInputString",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "35dp",
                "placeholder": "Enter any string",
                "secureTextEntry": false,
                "skin": "CopydefTextBoxNormal0eb3ea2bda04346",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "20dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var tbxcharacterarray = new voltmx.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerX": "50%",
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "tbxcharacterarray",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "35dp",
                "placeholder": "Enter character or string",
                "secureTextEntry": false,
                "skin": "CopydefTextBoxNormal0cb012c01b7674c",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "87dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var btnContainsChars = new voltmx.ui.Button({
                "centerX": "50.00%",
                "focusSkin": "CopydefBtnFocus0e823f9d584904d",
                "height": "50dp",
                "id": "btnContainsChars",
                "isVisible": true,
                "left": "9.34%",
                "onClick": controller.AS_Button_fde5c608939144d686ae6759b52972a6,
                "skin": "CopydefBtnNormal0ha60851fecb242",
                "text": "Contains Characters",
                "top": "176dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnGivenChars = new voltmx.ui.Button({
                "centerX": "50%",
                "focusSkin": "CopydefBtnFocus0e823f9d584904d",
                "height": "50dp",
                "id": "btnGivenChars",
                "isVisible": true,
                "left": "9.32%",
                "onClick": controller.AS_Button_a110352a7c5c4a93b7ed5bc8cdd5bd8f,
                "skin": "CopydefBtnNormal0ha60851fecb242",
                "text": "Contains only Given Charaters",
                "top": "237dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnNoGivenChars = new voltmx.ui.Button({
                "centerX": "50.00%",
                "focusSkin": "CopydefBtnFocus0e823f9d584904d",
                "height": "50dp",
                "id": "btnNoGivenChars",
                "isVisible": true,
                "left": "9.78%",
                "onClick": controller.AS_Button_baa75c532ce44eb0ac253fffbac7488b,
                "skin": "CopydefBtnNormal0ha60851fecb242",
                "text": "Contains No Given Characters",
                "top": "303dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnEndsWith = new voltmx.ui.Button({
                "centerX": "50.03%",
                "focusSkin": "CopydefBtnFocus0e823f9d584904d",
                "height": "50dp",
                "id": "btnEndsWith",
                "isVisible": true,
                "left": "35dp",
                "onClick": controller.AS_Button_cc94c900ceb64f1ab1c656c220054f62,
                "skin": "CopydefBtnNormal0ha60851fecb242",
                "text": "Check if the input string ends with the compare string",
                "top": "367dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnStartsWith = new voltmx.ui.Button({
                "centerX": "50%",
                "focusSkin": "CopydefBtnFocus0e823f9d584904d",
                "height": "50dp",
                "id": "btnStartsWith",
                "isVisible": true,
                "left": "35dp",
                "onClick": controller.AS_Button_b87bc09d66114586901d335d3c7cdef8,
                "skin": "CopydefBtnNormal0ha60851fecb242",
                "text": "Check if the input string starts with the compare string",
                "top": "433dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnNext = new voltmx.ui.Button({
                "centerX": "50%",
                "focusSkin": "CopydefBtnFocus0e823f9d584904d",
                "height": "50dp",
                "id": "btnNext",
                "isVisible": true,
                "left": "128dp",
                "onClick": controller.AS_Button_b443cc131f5545dc835b215dd475fed6,
                "skin": "CopydefBtnNormal0ha60851fecb242",
                "text": "Next",
                "top": "550dp",
                "width": "117dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBody.add(tbxInputString, tbxcharacterarray, btnContainsChars, btnGivenChars, btnNoGivenChars, btnEndsWith, btnStartsWith, btnNext);
            var flxHeader = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "53dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxHeader.setDefaultUnit(voltmx.flex.DP);
            var lblHeader = new voltmx.ui.Label({
                "centerX": "50.00%",
                "id": "lblHeader",
                "isVisible": true,
                "left": "123dp",
                "skin": "CopydefLabel0eae7d07926a246",
                "text": "String API",
                "textStyle": {},
                "top": "7dp",
                "width": voltmx.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnBack = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "80%",
                "id": "btnBack",
                "isVisible": true,
                "left": "0%",
                "onClick": controller.AS_Button_fcc4e67f31ea44999545af466fb9c068,
                "skin": "btnBasicColor",
                "text": "Back",
                "top": "0%",
                "width": "20%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeader.add(lblHeader, btnBack);
            var flxLabel = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "73dp",
                "id": "flxLabel",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0c38911b6bf5948",
                "top": "43dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxLabel.setDefaultUnit(voltmx.flex.DP);
            var lblInfo = new voltmx.ui.Label({
                "centerX": "50%",
                "id": "lblInfo",
                "isVisible": true,
                "left": "13dp",
                "skin": "CopydefLabel0d0fa1986c14943",
                "text": "Enter any two strings or characters in the below fields and compare the two strings.",
                "textStyle": {},
                "top": "12dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLabel.add(lblInfo);
            this.compInstData = {}
            this.add(flxBody, flxHeader, flxLabel);
        };
        return [{
            "addWidgets": addWidgetsForm1,
            "enabledForIdleTimeout": false,
            "id": "Form1",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});