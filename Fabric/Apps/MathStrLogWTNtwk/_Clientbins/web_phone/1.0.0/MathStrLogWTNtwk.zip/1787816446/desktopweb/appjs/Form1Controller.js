define("userForm1Controller", {
    //Type your controller code here 
    containsChars: function() {
        var inputstring = this.view.tbxInputString.text;
        var charsArr = [this.view.tbxcharacterarray.text];
        if (kony.string.containsChars(inputstring, charsArr) === true) {
            alert("The input string contains the characters" + "\n\rTextBox 1 is: " + inputstring + "\n\rTextBox 2 is: " + charsArr);
        } else {
            alert("The input string does not contain the characters" + "\n\rTextBox 1 is: " + inputstring + "\n\rTextBox 2 is: " + charsArr);
        }
    },
    contiansOnlyGivenChars: function() {
        var inputstring = this.view.tbxInputString.text;
        var charsArr = [this.view.tbxcharacterarray.text];
        if (kony.string.containsOnlyGivenChars(inputstring, charsArr) === true) {
            alert("The input string contains only the characters specified" + "\n\rTextBox 1 is: " + inputstring + "\n\rTextBox 2 is: " + charsArr);
        } else {
            alert("The input string contains other characters as well" + "\n\rTextBox 1 is: " + inputstring + "\n\rTextBox 2 is: " + charsArr);
        }
    },
    containsNoGivenChars: function() {
        var inputstring = this.view.tbxInputString.text;
        var charsArr = [this.view.tbxcharacterarray.text];
        if (kony.string.containsNoGivenChars(inputstring, charsArr) === true) {
            alert("The input string contains none of the characters specified" + "\n\rTextBox 1 is: " + inputstring + "\n\rTextBox 2 is: " + charsArr);
        } else {
            alert("The input string contains the character specified" + "\n\rTextBox 1 is: " + inputstring + "\n\rTextBox 2 is: " + charsArr);
        }
    },
    endsWith: function() {
        var sourcestring = this.view.tbxInputString.text;
        var comparestring = this.view.tbxcharacterarray.text;
        if (kony.string.endsWith(sourcestring, comparestring) === true) {
            alert("The input string ends with the string specified" + "\n\rTextBox 1 is: " + sourcestring + "\n\rTextBox 2 is: " + comparestring);
        } else {
            alert("The input string does not end with the string specified" + "\n\rTextBox 1 is: " + sourcestring + "\n\rTextBox 2 is: " + comparestring);
        }
    },
    equalsIgnoreCase: function() {
        var string1 = this.view.tbxInputString.text;
        var string2 = this.view.tbxcharacterarray.text;
        if (kony.string.equalsIgnoreCase(string1, string2) === true) {
            alert("The two strings are same");
        } else {
            alert("The two strings are different");
        }
    },
    startsWith: function() {
        var sourcestring = this.view.tbxInputString.text;
        var comparestring = this.view.tbxcharacterarray.text;
        if (kony.string.startsWith(sourcestring, comparestring) === true) {
            alert("The input string starts with the string specified" + "\n\rTextBox 1 is: " + sourcestring + "\n\rTextBox 2 is: " + comparestring);
        } else {
            alert("The input string does not start with the string specified" + "\n\rTextBox 1 is: " + sourcestring + "\n\rTextBox 2 is: " + comparestring);
        }
    },
});
define("Form1ControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
    /** onClick defined for btnGivenChars **/
    AS_Button_a110352a7c5c4a93b7ed5bc8cdd5bd8f: function AS_Button_a110352a7c5c4a93b7ed5bc8cdd5bd8f(eventobject) {
        var self = this;
        return self.contiansOnlyGivenChars.call(this);
    },
    /** onClick defined for btnNext **/
    AS_Button_b443cc131f5545dc835b215dd475fed6: function AS_Button_b443cc131f5545dc835b215dd475fed6(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation("Form2");
        ntf.navigate();
    },
    /** onClick defined for btnStartsWith **/
    AS_Button_b87bc09d66114586901d335d3c7cdef8: function AS_Button_b87bc09d66114586901d335d3c7cdef8(eventobject) {
        var self = this;
        return self.startsWith.call(this);
    },
    /** onClick defined for btnNoGivenChars **/
    AS_Button_baa75c532ce44eb0ac253fffbac7488b: function AS_Button_baa75c532ce44eb0ac253fffbac7488b(eventobject) {
        var self = this;
        return self.containsNoGivenChars.call(this);
    },
    /** onClick defined for btnEndsWith **/
    AS_Button_cc94c900ceb64f1ab1c656c220054f62: function AS_Button_cc94c900ceb64f1ab1c656c220054f62(eventobject) {
        var self = this;
        return self.endsWith.call(this);
    },
    /** onClick defined for btnBack **/
    AS_Button_fcc4e67f31ea44999545af466fb9c068: function AS_Button_fcc4e67f31ea44999545af466fb9c068(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation("FormHome");
        ntf.navigate();
    },
    /** onClick defined for btnContainsChars **/
    AS_Button_fde5c608939144d686ae6759b52972a6: function AS_Button_fde5c608939144d686ae6759b52972a6(eventobject) {
        var self = this;
        return self.containsChars.call(this);
    }
});
define("Form1Controller", ["userForm1Controller", "Form1ControllerActions"], function() {
    var controller = require("userForm1Controller");
    var controllerActions = ["Form1ControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
