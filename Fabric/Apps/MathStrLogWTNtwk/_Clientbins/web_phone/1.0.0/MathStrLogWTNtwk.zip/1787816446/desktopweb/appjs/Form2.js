define("Form2", function() {
    return function(controller) {
        function addWidgetsForm2() {
            this.setDefaultUnit(voltmx.flex.DP);
            var FlexContainer0j0929fecb58f40 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100.83%",
                "id": "FlexContainer0j0929fecb58f40",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            FlexContainer0j0929fecb58f40.setDefaultUnit(voltmx.flex.DP);
            var tbxInputString = new voltmx.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerX": "50.09%",
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "tbxInputString",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "35dp",
                "placeholder": "Enter any string",
                "secureTextEntry": false,
                "skin": "CopydefTextBoxNormal0b05f9ccaebaa49",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "80dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var btnASCII = new voltmx.ui.Button({
                "centerX": "50.03%",
                "focusSkin": "CopyCopydefBtnFocus",
                "height": "50dp",
                "id": "btnASCII",
                "isVisible": true,
                "left": "9.35%",
                "onClick": controller.AS_Button_ffc93511c40d490fb7486719739aa5a7,
                "skin": "CopyCopydefBtnNormal",
                "text": "Check whether the string contains ASCII alphabets",
                "top": "150dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnASCIIAlphanumeric = new voltmx.ui.Button({
                "centerX": "50.03%",
                "focusSkin": "CopyCopydefBtnFocus",
                "height": "50dp",
                "id": "btnASCIIAlphanumeric",
                "isVisible": true,
                "left": "9.36%",
                "onClick": controller.AS_Button_cbbba011771c485889c79bd8a325cbd8,
                "skin": "CopyCopydefBtnNormal",
                "text": "Check whether the string contains ASCII Alphanumeric characters",
                "top": "210dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopybtnASCIIAlphanumeric0a841e363f73848 = new voltmx.ui.Button({
                "centerX": "50.08%",
                "focusSkin": "CopyCopydefBtnFocus",
                "height": "50dp",
                "id": "CopybtnASCIIAlphanumeric0a841e363f73848",
                "isVisible": true,
                "left": "9.36%",
                "onClick": controller.AS_Button_j3c84be913db4dac8b2642b1041b60a1,
                "skin": "CopyCopydefBtnNormal",
                "text": "Check whether the string contains only Numeric characters",
                "top": "270dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnEmail = new voltmx.ui.Button({
                "centerX": "50.00%",
                "focusSkin": "CopyCopydefBtnFocus",
                "height": "50dp",
                "id": "btnEmail",
                "isVisible": true,
                "left": "10.08%",
                "onClick": controller.AS_Button_hcd129c656064f85b5186fad3e44d41f,
                "skin": "CopyCopydefBtnNormal",
                "text": "Validate the Email ID",
                "top": "330dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnConcatenate = new voltmx.ui.Button({
                "centerX": "50.03%",
                "focusSkin": "CopyCopydefBtnFocus",
                "height": "50dp",
                "id": "btnConcatenate",
                "isVisible": true,
                "left": "9.78%",
                "onClick": controller.AS_Button_a43e76ee73104833b93e0466de81f7f5,
                "skin": "CopyCopydefBtnNormal",
                "text": "Concatenate the string with itself",
                "top": "388dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnReverse = new voltmx.ui.Button({
                "centerX": "50.02%",
                "focusSkin": "CopyCopydefBtnFocus",
                "height": "50dp",
                "id": "btnReverse",
                "isVisible": true,
                "left": "9.82%",
                "onClick": controller.AS_Button_i71ed67f113a4f9c9416ee3daa4f9b8e,
                "skin": "CopyCopydefBtnNormal",
                "text": "Reverse the string",
                "top": "447dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnTrim = new voltmx.ui.Button({
                "centerX": "50.03%",
                "focusSkin": "CopyCopydefBtnFocus",
                "height": "50dp",
                "id": "btnTrim",
                "isVisible": true,
                "left": "9.80%",
                "onClick": controller.AS_Button_b02a75d104754b8fac7ea92d227a20d1,
                "skin": "CopyCopydefBtnNormal",
                "text": "Trim the String",
                "top": "508dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnBack = new voltmx.ui.Button({
                "focusSkin": "CopyCopydefBtnFocus",
                "height": "50dp",
                "id": "btnBack",
                "isVisible": true,
                "left": "29.30%",
                "onClick": controller.AS_Button_b6321e8aff4b4a4b83333e50c6e06d1e,
                "skin": "CopyCopydefBtnNormal",
                "text": "Back",
                "top": "583dp",
                "width": "149dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Label0e71f69cb7bd743 = new voltmx.ui.Label({
                "centerX": "50%",
                "id": "Label0e71f69cb7bd743",
                "isVisible": true,
                "left": "134dp",
                "skin": "CopydefLabel0fa7c847e104247",
                "text": "String API also allows you to perform following operations",
                "textStyle": {},
                "top": "12dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlexContainer0j0929fecb58f40.add(tbxInputString, btnASCII, btnASCIIAlphanumeric, CopybtnASCIIAlphanumeric0a841e363f73848, btnEmail, btnConcatenate, btnReverse, btnTrim, btnBack, Label0e71f69cb7bd743);
            this.compInstData = {}
            this.add(FlexContainer0j0929fecb58f40);
        };
        return [{
            "addWidgets": addWidgetsForm2,
            "enabledForIdleTimeout": false,
            "id": "Form2",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});