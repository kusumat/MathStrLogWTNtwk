define("FormHome", function() {
    return function(controller) {
        function addWidgetsFormHome() {
            this.setDefaultUnit(voltmx.flex.DP);
            var btnMath = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "10%",
                "id": "btnMath",
                "isVisible": true,
                "left": "25%",
                "onClick": controller.AS_Button_f877f06edfda47bfbb10095191c22457,
                "skin": "btnBasicColor",
                "text": "Math API",
                "top": "10%",
                "width": "50%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnStringHome = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "10%",
                "id": "btnStringHome",
                "isVisible": true,
                "left": "25%",
                "onClick": controller.AS_Button_f00aced87d16451b9174a93dcfa5e85b,
                "skin": "btnBasicColor",
                "text": "String API",
                "top": "25%",
                "width": "50%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnLog = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "10%",
                "id": "btnLog",
                "isVisible": true,
                "left": "25%",
                "onClick": controller.AS_Button_f44ca0fa7ea6416cbd9af14ac6f639bd,
                "skin": "btnBasicColor",
                "text": "Logging API",
                "top": "40%",
                "width": "50%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnWokerThread = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "10%",
                "id": "btnWokerThread",
                "isVisible": true,
                "left": "25.00%",
                "onClick": controller.AS_Button_d5a6a41a9348465da73237294d0f53b0,
                "skin": "btnBasicColor",
                "text": "Worker Thread API",
                "top": "55%",
                "width": "50%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnNetworkApi = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "10%",
                "id": "btnNetworkApi",
                "isVisible": true,
                "left": "25.00%",
                "onClick": controller.AS_Button_hc1de9ffba744604a8985d2c05d6bcb5,
                "skin": "btnBasicColor",
                "text": "Network API",
                "top": "70%",
                "width": "50%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            this.compInstData = {}
            this.add(btnMath, btnStringHome, btnLog, btnWokerThread, btnNetworkApi);
        };
        return [{
            "addWidgets": addWidgetsFormHome,
            "enabledForIdleTimeout": false,
            "id": "FormHome",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});