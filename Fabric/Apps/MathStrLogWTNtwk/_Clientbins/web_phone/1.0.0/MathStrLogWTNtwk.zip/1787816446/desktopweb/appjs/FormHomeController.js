define("userFormHomeController", {
    //Type your controller code here 
});
define("FormHomeControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_f44ca0fa7ea6416cbd9af14ac6f639bd: function AS_Button_f44ca0fa7ea6416cbd9af14ac6f639bd(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation("FormLog");
        ntf.navigate();
    },
    AS_Button_f877f06edfda47bfbb10095191c22457: function AS_Button_f877f06edfda47bfbb10095191c22457(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation("frmHomeMath");
        ntf.navigate();
    },
    AS_Button_hc1de9ffba744604a8985d2c05d6bcb5: function AS_Button_hc1de9ffba744604a8985d2c05d6bcb5(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation("FormNetworkApi");
        ntf.navigate();
    },
    AS_Button_f00aced87d16451b9174a93dcfa5e85b: function AS_Button_f00aced87d16451b9174a93dcfa5e85b(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation("Form1");
        ntf.navigate();
    },
    AS_Button_d5a6a41a9348465da73237294d0f53b0: function AS_Button_d5a6a41a9348465da73237294d0f53b0(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation("FormWorkerThread");
        ntf.navigate();
    }
});
define("FormHomeController", ["userFormHomeController", "FormHomeControllerActions"], function() {
    var controller = require("userFormHomeController");
    var controllerActions = ["FormHomeControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
