define("FormLog", function() {
    return function(controller) {
        function addWidgetsFormLog() {
            this.setDefaultUnit(voltmx.flex.DP);
            var btnBack = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "7%",
                "id": "btnBack",
                "isVisible": true,
                "left": "0%",
                "onClick": controller.AS_Button_fb88d26d35aa419cb69f03ee5d729e3a,
                "skin": "btnBasicColor",
                "text": "Back",
                "top": "0%",
                "width": "20%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnGenerate = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "7%",
                "id": "btnGenerate",
                "isVisible": true,
                "left": "10%",
                "onClick": controller.AS_Button_f3e379d7313c4b74b10277426ce0acc7,
                "skin": "btnBasicColor",
                "text": "Generate Logs",
                "top": "10%",
                "width": "50%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lbConf = new voltmx.ui.Label({
                "height": "7%",
                "id": "lbConf",
                "isVisible": false,
                "left": "2%",
                "skin": "CopydefLabel0ed307f3b658944",
                "text": "Generated logs please check console or seg",
                "textStyle": {},
                "top": "20%",
                "width": "95%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var segLogData = new voltmx.ui.SegmentedUI2({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "data": [{
                    "lblDescription": "",
                    "lblHeading": "",
                    "lblStrip": "",
                    "lblTime": ""
                }],
                "groupCells": false,
                "height": "70%",
                "id": "segLogData",
                "isVisible": true,
                "left": "0.00%",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "flxSampleRowTemplate",
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "30%",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxSampleRowTemplate": "flxSampleRowTemplate",
                    "lblDescription": "lblDescription",
                    "lblHeading": "lblHeading",
                    "lblStrip": "lblStrip",
                    "lblTime": "lblTime"
                },
                "width": "100%"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            this.compInstData = {}
            this.add(btnBack, btnGenerate, lbConf, segLogData);
        };
        return [{
            "addWidgets": addWidgetsFormLog,
            "enabledForIdleTimeout": false,
            "id": "FormLog",
            "init": controller.AS_Form_daa712c4d67c4bc8b3c3d98d76dba540,
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});