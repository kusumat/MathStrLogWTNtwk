define("FormNetworkApi", function() {
    return function(controller) {
        function addWidgetsFormNetworkApi() {
            this.setDefaultUnit(voltmx.flex.DP);
            var btnClearCookies = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "7%",
                "id": "btnClearCookies",
                "isVisible": true,
                "left": "10%",
                "onClick": controller.AS_Button_d5e93031e4b9425f9c93937796cbdcc9,
                "skin": "btnBasicColor",
                "text": "Clear Cookies",
                "top": "10%",
                "width": "80%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnFormData = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "7%",
                "id": "btnFormData",
                "isVisible": true,
                "left": "10%",
                "onClick": controller.AS_Button_b8f134c2b10741368f9cade45998081f,
                "skin": "btnBasicColor",
                "text": "Form Data",
                "top": "20%",
                "width": "80%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnIsNetworkAvailable = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "7%",
                "id": "btnIsNetworkAvailable",
                "isVisible": true,
                "left": "10%",
                "onClick": controller.AS_Button_h22d1af9f3c24c2c83b39a3f490e3005,
                "skin": "btnBasicColor",
                "text": "Is Network Available",
                "top": "30%",
                "width": "80%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnHttpRequest = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "7%",
                "id": "btnHttpRequest",
                "isVisible": true,
                "left": "10%",
                "onClick": controller.AS_Button_bfc573baacd54305a8cb3e324a4b204f,
                "skin": "btnBasicColor",
                "text": "Http Request",
                "top": "40%",
                "width": "80%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnNetType = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "7%",
                "id": "btnNetType",
                "isVisible": true,
                "left": "10%",
                "onClick": controller.AS_Button_d60f34b6ef3e4a80896d32e3ecc11d33,
                "skin": "btnBasicColor",
                "text": "Network Type",
                "top": "50%",
                "width": "80%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnNetCallBack = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "7%",
                "id": "btnNetCallBack",
                "isVisible": true,
                "left": "10%",
                "onClick": controller.AS_Button_c1591d9669704816a2165fbc04dd6023,
                "skin": "btnBasicColor",
                "text": "Network Callbacks",
                "top": "60%",
                "width": "80%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxHeader = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "6.91%",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0cff13f9dfcda46",
                "top": "0dp",
                "width": "100%"
            }, {}, {});
            flxHeader.setDefaultUnit(voltmx.flex.DP);
            var lblHeader = new voltmx.ui.Label({
                "centerX": "56.76%",
                "centerY": "44.64%",
                "height": "43dp",
                "id": "lblHeader",
                "isVisible": true,
                "left": "50%",
                "skin": "CopydefLabel0g48a8e10979c4b",
                "text": "Network API",
                "textStyle": {},
                "top": "20%",
                "width": "44.69%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnBack = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btnBack",
                "isVisible": true,
                "left": "0%",
                "onClick": controller.AS_Button_f01b40a71bd443889a5846892ce7fc1f,
                "skin": "btnBasicColor",
                "text": "Back",
                "top": "0%",
                "width": "20%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeader.add(lblHeader, btnBack);
            var infoContainer = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "163dp",
                "id": "infoContainer",
                "isVisible": false,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "CopyslFbox0d0cb417244494a",
                "top": "7%",
                "width": "100%"
            }, {}, {});
            infoContainer.setDefaultUnit(voltmx.flex.DP);
            var btnGreen = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "20%",
                "id": "btnGreen",
                "isVisible": true,
                "left": "5%",
                "skin": "btnGreen",
                "top": "10%",
                "width": "20%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnBlue = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "20%",
                "id": "btnBlue",
                "isVisible": true,
                "left": "5.31%",
                "skin": "CopydefBtnNormal0jaf7a0dc4ea34cBLUE",
                "top": "49.69%",
                "width": "20%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lbGreen = new voltmx.ui.Label({
                "id": "lbGreen",
                "isVisible": true,
                "left": "30%",
                "skin": "CopydefLabel0h93f671c8ac04f",
                "text": "After successful API call",
                "textStyle": {},
                "top": "10%",
                "width": "60%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lbBlue = new voltmx.ui.Label({
                "id": "lbBlue",
                "isVisible": true,
                "left": "30%",
                "skin": "blueLb",
                "text": "Before API call",
                "textStyle": {},
                "top": "52%",
                "width": "50%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            infoContainer.add(btnGreen, btnBlue, lbGreen, lbBlue);
            this.compInstData = {}
            this.add(btnClearCookies, btnFormData, btnIsNetworkAvailable, btnHttpRequest, btnNetType, btnNetCallBack, flxHeader, infoContainer);
        };
        return [{
            "addWidgets": addWidgetsFormNetworkApi,
            "enabledForIdleTimeout": false,
            "id": "FormNetworkApi",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});