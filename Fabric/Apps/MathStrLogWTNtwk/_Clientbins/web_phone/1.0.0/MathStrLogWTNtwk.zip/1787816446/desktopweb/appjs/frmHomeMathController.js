define("userfrmHomeMathController", {
    onclickfloor: function() {
        var a = this.view.tbxOperations.text;
        var b = Math.floor(a);
        alert("The converted value is " + b + "\n\rEntered Number is: " + a);
    },
    onclicksqrt: function() {
        var a = this.view.tbxOperations.text;
        var b = Math.sqrt(a);
        alert("The square root value is " + b + "\n\rEntered Number is: " + a);
    },
    onclickpow: function() {
        var a = this.view.tbxOperations.text;
        var b = Math.pow(a, 2);
        alert("The Squared value is " + b + "\n\rEntered Number is: " + a);
    },
    onclickmax: function() {
        var a = this.view.tbxNumber1.text;
        var b = this.view.tbxNumber2.text;
        var c = Math.max(a, b);
        alert("The maximum value is " + c + "\n\rNumber1 is: " + a + "\n\rNumber2 is: " + b);
    },
    onclickmin: function() {
        var a = this.view.tbxNumber1.text;
        var b = this.view.tbxNumber2.text;
        var c = Math.min(a, b);
        alert("The minimum value is " + c + "\n\rNumber1 is: " + a + "\n\rNumber2 is: " + b);
    },
    onclickpi: function() {
        var pi = Math.PI;
        alert("The pi value is " + pi);
    },
    onclickRandom: function() {
        var random = Math.random();
        alert("The random number is " + random);
    }
});
define("frmHomeMathControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_e6fd620b34ba43cb9960148a0d208a54: function AS_Button_e6fd620b34ba43cb9960148a0d208a54(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation("FormHome");
        ntf.navigate();
    },
    AS_Button_f2f9acb42bc34e08ab246e3a438d4d43: function AS_Button_f2f9acb42bc34e08ab246e3a438d4d43(eventobject) {
        var self = this;
        return self.onclickfloor.call(this);
    },
    AS_Button_h7dc45cce50b413ca9d27eb0ea6b6e86: function AS_Button_h7dc45cce50b413ca9d27eb0ea6b6e86(eventobject) {
        var self = this;
        return self.onclickmax.call(this);
    },
    AS_Button_ia60da3bdb78437fb34f57233e2ed7dd: function AS_Button_ia60da3bdb78437fb34f57233e2ed7dd(eventobject) {
        var self = this;
        return self.onclickmin.call(this);
    },
    AS_Button_b8cde15fdc63489f9b43ac621a06962f: function AS_Button_b8cde15fdc63489f9b43ac621a06962f(eventobject) {
        var self = this;
        return self.onclickRandom.call(this);
    },
    AS_Button_b9e692526422450abd72cf5124afe0bf: function AS_Button_b9e692526422450abd72cf5124afe0bf(eventobject) {
        var self = this;
        return self.onclicksqrt.call(this);
    },
    AS_Button_eceaec49f3364afb95f999591d10ef54: function AS_Button_eceaec49f3364afb95f999591d10ef54(eventobject) {
        var self = this;
        return self.onclickpow.call(this);
    },
    AS_Button_d4eee92eed7d4e4c9566ad51f909c202: function AS_Button_d4eee92eed7d4e4c9566ad51f909c202(eventobject) {
        var self = this;
        return self.onclickpi.call(this);
    },
    AS_TextField_cda1342cfb0749b499c830cd53551f00: function AS_TextField_cda1342cfb0749b499c830cd53551f00(eventobject, changedtext) {
        var self = this;
    }
});
define("frmHomeMathController", ["userfrmHomeMathController", "frmHomeMathControllerActions"], function() {
    var controller = require("userfrmHomeMathController");
    var controllerActions = ["frmHomeMathControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
